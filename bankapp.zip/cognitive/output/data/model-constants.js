'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var ACCOUNT_MODEL = exports.ACCOUNT_MODEL = 'accounts';
var BENEFICIARY_MODEL = exports.BENEFICIARY_MODEL = 'beneficiaries';
var SESSION_MODEL = exports.SESSION_MODEL = 'sessions';