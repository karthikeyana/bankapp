'use strict';

export const ACCOUNT_MODEL = 'accounts';
export const BENEFICIARY_MODEL = 'beneficiaries';
export const SESSION_MODEL = 'sessions';

